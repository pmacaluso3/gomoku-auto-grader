package learn.gomoku.ui;
import learn.gomoku.game.Gomoku;
import learn.gomoku.game.Stone;
import learn.gomoku.game.Result;
import learn.gomoku.players.HumanPlayer;
import learn.gomoku.players.Player;
import learn.gomoku.players.RandomPlayer;

import java.util.Scanner;

public class GameController {
    private Scanner console = new Scanner(System.in);
    private char[][] board;
    private Gomoku game;

    public void run() { // the app class makes this run
        boolean playAgain = true;

        while (playAgain) {
            // set up players & instantiate game
            Gomoku game = setup();

            // play the game
            playGomoku(game);

            // prompt user if they would like to play again (until they enter a valid response)
            String yOrN = "";
            do {
                System.out.println("Would you like to play again? [y/n]: ");
                yOrN = console.nextLine();
                if (yOrN.equalsIgnoreCase("y")) {
                    playAgain = true;
                } else {
                    playAgain = false;
                }
            } while (!yOrN.equalsIgnoreCase("y") && !yOrN.equalsIgnoreCase("n"));

        }

        System.out.println("Thank you for playing Gomoku! (:");
    }

    private Gomoku setup() {
        printWithHeader("Welcome to Gomoku");

        Player playerOne = null;
        Player playerTwo = null;

        // creating player 1
        playerOne = makeNewPlayer(1);

        // creating player 2
        playerTwo = makeNewPlayer(2);

        // creating the Gomoku game
        Gomoku game = Gomoku.createGomokuInstance(playerOne, playerTwo);

        System.out.println("\nRandomizing...");
        System.out.printf("%s goes first.%n%n", game.getCurrent().getName());

        return game;
    }

    private Player makeNewPlayer(int playerNumber) {
        System.out.println();
        String humanOrRandom = "";
        Player newPlayer = null;

        do { // creating player # 1/2
            System.out.printf("Player %s is:\n1. Human Player\n2. Random Player\nSelect [1-2]: ", playerNumber);
            humanOrRandom = console.nextLine();

            if (humanOrRandom.equals("1")) { // create a human player
                System.out.printf("Player %s, enter your name: ", playerNumber);
                String name = console.nextLine();
                newPlayer = new HumanPlayer(name);
            } else if (humanOrRandom.equals("2")) { // create a random player
                newPlayer = new RandomPlayer();
            }
        } while (!humanOrRandom.equals("1") && !humanOrRandom.equals("2"));

        return newPlayer;
    }

    private void playGomoku(Gomoku game) {
        while (!game.isOver()) { // each individual game
            Player currentPlayer = game.getCurrent();
            Stone stone = null;

            if (currentPlayer.generateMove(game.getStones()) == null) { // if current player is human
                printWithHeader(String.format("%s's Turn:", currentPlayer.getName()));
                // ask current player for row and column
                System.out.print("Enter a row: ");
                int row = getValidInteger() - 1;
                System.out.print("Enter a column: ");
                int col = getValidInteger() - 1;

                stone = new Stone(row, col, game.isBlacksTurn()); // creates stone

            } else { // player is random
                printWithHeader(String.format("%s's Turn:", currentPlayer.getName()));
                stone = currentPlayer.generateMove(game.getStones());
            }

            Result result = game.place(stone); // places stone

            if (!result.isSuccess()) { // prints message if move was invalid
                System.out.printf("%n%s%n%n",result.getMessage());
            } else {
                printBoard(game); // if move was valid, print the updated board
            }
        }

        // after the game is over...
        Player winner = game.getWinner(); // check if there is a winner (or tie)
        if (winner != null) {
            System.out.printf("%s won the game!%n", game.getWinner().getName());
        } else { // check if they are tied
            System.out.println("There is a tie!");
        }

    }

    private void printBoard(Gomoku game) {
        // header with column numbers
        System.out.println("\n  01 02 03 04 05 06 07 08 09 10 11 12 13 14 15");

        for (int row=0; row < 15; row++) { // prints out each row
            // row numbers on left side
            if (row < 9) {
                System.out.printf("0%s", row+1);
            } else {
                System.out.print(row+1);
            }

            for (int col= 0; col < 15; col++) { // prints out each column
                boolean stonePrinted = false;

                // if there is a stone at that location, must print stone. otherwise print "_"
                for (Stone stone : game.getStones()) {
                    if (stone.getRow() == row && stone.getColumn() == col) { // there is a stone at this location
                        // print black or white stone
                        if (stone.isBlack()) {
                            System.out.print(" B ");
                        } else {
                            System.out.print(" W ");
                        }

                        stonePrinted = true;
                    }
                }
                if (!stonePrinted) { // if there is no stone print "="
                    System.out.print(" _ ");
                }
            }
            System.out.println(); // start new line for next row
        }
        System.out.println(); // empty line after board is printed
    }

    public int getValidInteger() {
        // validates that the user input is numeric before parsing it into an int
        // (avoids runtime error)
        boolean validNumber = false;
        String numberString = "";

        while (!validNumber) {
            numberString = console.nextLine(); // user input
            for (int i = 0; i < numberString.length(); i++) {
                if (!Character.isDigit(numberString.charAt(i))) {
                    validNumber = false;
                }
                else {
                    validNumber = true;
                }
            }
            if (!validNumber) {
                System.out.print("Invalid input. Please enter a number: ");
            }
        }

        return Integer.parseInt(numberString);
    }

    private void printWithHeader(String string) {
        System.out.println(string);
        System.out.println("=".repeat(string.length()));
    }

}
